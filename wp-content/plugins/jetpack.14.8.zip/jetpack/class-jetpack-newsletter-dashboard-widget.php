<?php
/**
 * Jetpack Newsletter Dashboard Widget.
 *
 * @deprecated 14.6
 * The class now lives within the Subscriptions module directory.
 *
 * @package jetpack
 */

_deprecated_file( __FILE__, 'jetpack-14.6', JETPACK__PLUGIN_DIR . '/modules/subscriptions/dashboard-widget/class-jetpack-newsletter-dashboard-widget.php' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
