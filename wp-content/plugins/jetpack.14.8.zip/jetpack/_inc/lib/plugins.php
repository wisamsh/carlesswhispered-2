<?php
/**
 * This file has been moved to the jetpack-plugins-installer package
 *
 * @deprecated 10.7
 *
 * @package jetpack
 */

class_alias( Automattic\Jetpack\Plugins_Installer::class, 'Jetpack_Plugins' );
