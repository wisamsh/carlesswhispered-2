<?php return array('dependencies' => array(), 'version' => 'a13aed56478ae1f1f596');
