<?php return array('dependencies' => array(), 'version' => '55b16ceb57cbf70e9633');
