<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '44964dfd791700150810');
