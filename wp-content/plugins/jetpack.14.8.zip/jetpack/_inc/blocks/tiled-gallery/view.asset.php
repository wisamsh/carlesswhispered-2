<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '6ce82d684591be7bf162');
