<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'abe8223db1350b0217b3');
