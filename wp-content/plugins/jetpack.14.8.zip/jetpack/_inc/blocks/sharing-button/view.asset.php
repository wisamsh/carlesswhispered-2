<?php return array('dependencies' => array(), 'version' => 'a996a3c1a39f4a9e4998');
