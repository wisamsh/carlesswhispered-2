<?php return array('dependencies' => array('wp-polyfill'), 'version' => '32a8501e8647dda360bd');
