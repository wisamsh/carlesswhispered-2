<?php return array('dependencies' => array(), 'version' => 'ecf799cab7ccf5d52885');
