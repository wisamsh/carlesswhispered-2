<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '1e2405bb918d585fe7bd');
