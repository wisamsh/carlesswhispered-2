<?php return array('dependencies' => array('wp-polyfill'), 'version' => '0489bf2f755faa1d84ec');
