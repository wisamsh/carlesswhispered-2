<?php return array('dependencies' => array(), 'version' => '5ed55d72753c0dbc9e07');
