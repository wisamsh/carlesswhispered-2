<?php return array('dependencies' => array(), 'version' => '43aeb6d34372ef0bea37');
