<?php return array('dependencies' => array(), 'version' => 'aebc1f4d75f21cfa2f41');
