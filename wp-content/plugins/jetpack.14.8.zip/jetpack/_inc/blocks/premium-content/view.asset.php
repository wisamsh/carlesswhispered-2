<?php return array('dependencies' => array('wp-polyfill'), 'version' => '649823996b7820174c4e');
