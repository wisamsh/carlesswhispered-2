<?php return array('dependencies' => array(), 'version' => 'acdb4ccfec08b62c30cc');
