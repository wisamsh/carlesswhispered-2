<?php return array('dependencies' => array(), 'version' => '6e2dd5e814bcfd05b514');
