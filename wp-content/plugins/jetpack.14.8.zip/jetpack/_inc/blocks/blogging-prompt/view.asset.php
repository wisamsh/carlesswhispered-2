<?php return array('dependencies' => array(), 'version' => '27c95720482d6e33f60b');
