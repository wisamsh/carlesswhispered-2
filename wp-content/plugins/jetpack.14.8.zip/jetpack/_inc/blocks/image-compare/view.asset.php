<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '0c97cef15074f68d9ea4');
