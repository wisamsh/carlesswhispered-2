<?php return array('dependencies' => array(), 'version' => 'a1b1c6c503f30bcab4ec');
